This is a modified version of GLEW to support latest extensions of
the GeForce 8800.
